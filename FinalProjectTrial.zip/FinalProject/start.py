from email import message
import os
import psycopg2
from flask import Flask, redirect, render_template, request

app = Flask(__name__)

def get_db_connection():

    conn = psycopg2.connect(
        "dbname=bicycleProject user=postgres host=localhost password=Eclipse70!"
    )

    return conn

@app.route('/')
def start():
    return render_template('registration.html')

@app.route('/', methods=['POST', 'GET'])
def registration():
    print('here')
    if request.method == 'POST':
        name = request.form['fullname']
        email = request.form['fullemail']
        user = request.form['usrnme']
        pasw = request.form['pswd']
        conn = get_db_connection()
        cur = conn.cursor()
        # RUN CODE BELOW THE FIRST TIME ONLY
        # cur.execute('CREATE TABLE regis(name varchar(150), email varchar(150), username varchar(150), password varchar(150))')
        cur.execute('SELECT * FROM regis;')
        books = cur.fetchall()
        if name == '' or email == '' or user == '' or pasw == '':
            exists = 'Fields can not be left empty!'
            return render_template('registration.html', exists = exists)
        for i in range(0,len(books)):
            if books[i][0] == name and books[i][1] == email:
                exists = 'User already exists, Try login in instead!'
                return render_template('registration.html', exists = exists)
        cur.execute('INSERT INTO regis(name, email, username, password) VALUES(%s, %s, %s, %s)', (name,email,user,pasw))
        conn.commit()
        cur.execute('SELECT * FROM regis;')
        books = cur.fetchall()
        cur.close()
        conn.close()
    return render_template('/templates/login.html', books = books)


@app.route('/login')
def log():
    return render_template('login.html')
    
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM regis;')
        books = cur.fetchall()
        user2 = request.form['fullname1']
        pasw2 = request.form['pswrd1']
        for i in range(0,len(books)):
            if books[i][2] == user2:
                if books[i][3] == pasw2:
                    cur.close()
                    conn.close()
                    return render_template('shop.html')
                else:
                    cur.close()
                    conn.close()
                    return render_template('login.html', message = 'WRONG PASSWORD')
        cur.close()
        conn.close()
        return render_template('login.html', books = books, message = 'WRONG USERNAME OR PASSWORD')

@app.route('/shop', methods=['POST', 'GET'])
def shop():
    return render_template('shop.html')
                

if __name__ == '__main__':
    app.run(debug=True)
