from email import message
import os
import psycopg2
from flask import Flask, redirect, url_for, render_template, request

app = Flask(__name__)

# un-comment whichever database connector works with your system and comment out whichever doesn't

## windows database connector
# def get_db_connection():

#     conn = psycopg2.connect(
#         "dbname=bicycle user=postgres host=localhost password=16142003Da."  #REMEMBER TO CHANGE THE PASSWORD
#     )

#     return conn

# mac database connector
def get_db_connection():
    conn = psycopg2.connect(
        host = 'localhost',
        database = 'bicycle'
    )
    return conn

@app.route('/')
def start():
    return render_template('registration.html')

@app.route('/', methods=['POST', 'GET'])
def registration():
    print('here')
    if request.method == 'POST':
        name = request.form['fullname']
        email = request.form['fullemail']
        user = request.form['usrnme']
        pasw = request.form['pswd']
        conn = get_db_connection()
        cur = conn.cursor()
        # RUN CODE BELOW THE FIRST TIME ONLY
        # cur.execute('CREATE TABLE bicycle (id SERIAL,name varchar(225),email varchar(225),username varchar(225),password varchar(255),bicycle varchar(255),price numeric)')
        cur.execute('SELECT * FROM bicycle;')
        books = cur.fetchall()
        if name == '' or email == '' or user == '' or pasw == '':
            exists = 'Fields can not be left empty!'
            print('here')
            return render_template('registration.html', exists = exists)
        for i in range(0,len(books)):
            if books[i][0] == name and books[i][1] == email:
                exists = 'User already exists, Try login in instead!'
                print('here')
                return render_template('registration.html', exists = exists)
        cur.execute('INSERT INTO bicycle(name, email, username, password) VALUES(%s, %s, %s, %s)', (name,email,user,pasw))
        conn.commit()
        cur.execute('SELECT * FROM bicycle;')
        books = cur.fetchall()
        cur.close()
        conn.close()
        return redirect(url_for('login'))

@app.route('/login')
def log():
    return render_template('login.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM bicycle')
        books = cur.fetchall()
        user2 = request.form['fullname1']
        pasw2 = request.form['pswrd1']
        global place
        place = 0
        for i in range(0,len(books)):
            if books[i][2] == user2:
                if books[i][3] == pasw2:
                    cur.close()
                    conn.close()
                    return render_template('shop.html')
                else:
                    print('WRONG PASSWORD')
                    cur.close()
                    conn.close()
                    return redirect(url_for('login'))
            place = place + 1
        print('WRONG USERNAME OR PASSWORD')
        cur.close()
        conn.close()
        return render_template('login.html', books = books)

@app.route('/shop')
def shop():
    return render_template('shop.html')

@app.route('/shop', methods = ['POST', 'GET'])
def buy():
    if request.method == 'POST':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM bicycle')
        bikes = cur.fetchall()
       
        if request.form['bike'] == 'Buy Custom Bike #5':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Custom Bike #5', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy Peak Design Collab #1':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Peak Design Collab #1', 4599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy Classic Bike #1':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Classic Bike #1', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy The Schwinn Bike':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'The Schwinn Bike', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy The Dual Bike':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'The Dual Bike', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy Unique Bike':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Unique Bike', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy Retro Bike #3':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Retro Bike #3', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy Modern Bike #9':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Modern Bike #9', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy Retro Bike #2':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Retro Bike #2', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        elif request.form['bike'] == 'Buy Classic Bike #7':
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        (bikes[place][1], bikes[place][2], bikes[place][3], bikes[place][4], 'Classic Bike #7', 599.95))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')
        else:
            cur.execute('INSERT INTO bicycle (name, email, username, password, bicycle, price)'
                        'VALUES(%s, %s, %s, %s, %s, %s)',
                        ('error', 'error', 'error', 'error', 'error', 0))
            conn.commit()
            cur.close()
            conn.close()
            return render_template('login.html')

if __name__ == '__main__':
    app.run(debug = True)